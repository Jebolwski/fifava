$(window).on("load", function() {
    setTimeout(removeLoader, 2000);
});